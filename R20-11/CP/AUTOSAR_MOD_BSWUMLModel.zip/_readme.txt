Document Title:                 Basic Software UML Model
Document Owner:                 AUTOSAR
Document Responsibility:        AUTOSAR
Document Identification Number: 52
Document Status:                published
Part of AUTOSAR Standard:       Classic Platform
Part of Standard Release:       R20-11
Date:                           2020-11-30
